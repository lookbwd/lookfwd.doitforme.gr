#include <stdio.h>

main()
{
    printf("HELLO WORLD");
}
