#include <stdio.h>

#define maxstates 4

main()
{
int state=0;
char statchar[maxstates]="AEOI";
int ch;

while (ch!=10 && state<maxstates) {
	ch = getchar();
	if ( ch==statchar[state] ) state++;
	}

if (state == maxstates) printf("This string was OK\n");
		else printf("This string was NOT OK\n");
}
