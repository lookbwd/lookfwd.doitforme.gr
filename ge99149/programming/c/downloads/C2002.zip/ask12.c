#include <stdio.h>
#include <string.h>
#define MAX_WORD_LENGTH 20

typedef struct DMTemp {
    struct CL * next;
    char data[MAX_WORD_LENGTH];
    int frequency;
} CL;

void insertNode(CL ** CLHead,char * newword)
{
    CL * newElement;
    newElement = (CL *) malloc( sizeof(CL) );
    newElement->next = *CLHead;
    strcpy(newElement->data,newword);
    newElement->frequency = 1;
    *CLHead = newElement;
}

void printVector(CL *CLHead,int i)
{
    if (CLHead != NULL)
    {   if (i<3)
        {
            printf("%11s : %d  ",CLHead->data, CLHead->frequency);
            i++;
        }
        else
        {
            i=0;
            printf("%11s : %d\n",CLHead->data, CLHead->frequency);
        }
        printVector(CLHead->next,i);
    }
}

void addWord(CL **CLHead,char *word)
{
    if ( (*CLHead) != NULL )
    {
        if (strcmp(word,(*CLHead)->data))
        {
            addWord(&((*CLHead)->next),word);
	} else
        {
            ((*CLHead)->frequency)++;
	}
    } else
    {
        insertNode(CLHead,word);
    }
}

int main(void)
{
    CL * CLHead = NULL;
    char word[MAX_WORD_LENGTH];
    int check;
    FILE *In;

    In = fopen("text.txt","rt");

    check=1;
    while (check==1)
    {
        check = fscanf(In,"%s",word);
        if (check==1)
	{
            addWord(&CLHead,word);
        }
    }
    fclose(In);

    printVector(CLHead,0);
}
