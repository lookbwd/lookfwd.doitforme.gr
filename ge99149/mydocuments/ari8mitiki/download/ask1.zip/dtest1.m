function f=dtest1(x)

% First test function for NR Method

f= - 51* x.^50 + 50 * x.^49 + 1;