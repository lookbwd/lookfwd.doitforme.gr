function f=dtest2(x)

% First test function for NR Method

f= -sin(cos(cos(x)))*sin(cos(x))*sin(x);