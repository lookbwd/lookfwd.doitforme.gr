function [x,iter,dits] = nr3(f,h,x0,maxit,digits,exact)
% Root of f(x)=0 by Newton-Raphson's Method
% method terminates when relative change > tol
% or maxinmum number exceeds of iterations
if nargin < 3, fprintf('insufficient input\n'); break; end;
if nargin < 4, maxit = 100; end;
if nargin < 5, tol = eps; end;
x=x0; iter = 0; xdiff = inf; dits=0;


while dits<digits
    iter = iter +1; xold = x;
    deltaf = (feval(f,(x+h))-feval(f,x-h))/(2*h);
    x = x - feval(f,x)/ deltaf;

    xdiff = abs(x-xold)/abs(x);
	dits = -log10 (abs(x-exact));

    if iter > maxit
        fprintf('Not coverged after %d iterations.', maxit);
        break;
    end
end