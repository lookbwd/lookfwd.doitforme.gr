function f=test2(x)

% First test function for NR Method

am = 149;

f= cos(cos(cos(x))) - (3 * am) / (4 * ( am + 1 ) );