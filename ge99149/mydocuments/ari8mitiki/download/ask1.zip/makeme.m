repeatch=0;
while (repeatch~=2)
repeatch=0;
choise1=0;
choise2=0;
choise3=0;
repit=100;

disp('Wellcome to Exercise 1 of Numerical Analysis I');
disp('Created by Dimitris Kousis - Loucas 2002 (GE99149)');
disp('There are two functions to test Newton Raphson''s method');
disp('------- Choose a function -------');
disp(' ');
disp('1. f= - x.^51 + x.^50 + x - am / ( am + 10 )');
disp('2. f= cos(cos(cos(x))) - (3 * am) / (4 * ( am + 1 ) ) ');
disp(' ');
while (choise1~=1)&(choise1~=2)
choise1=input('Please select one: ');
end

if choise1==1
    f=@test1;
    df=@dtest1;
    x0=0.99;
    x00=0.9;
else
    f=@test2;
    df=@dtest2;
    x0=1.35;
    x00=1.35;
end

disp(' ');disp(' ');disp(' ');
disp('There are three parts of the exercise');
disp('Which one would you like to run?');
disp(' ');
disp('1. Simple Results of execution');
disp('2. Graphs of error vs repeations');
disp('3. Graphs of time vs digits of accuracy');
while (choise2~=1)&(choise2~=2)&(choise2~=3)
choise2=input('Please select one: ');
end

if choise2~=3
disp(' ');disp(' ');disp(' ');
disp('There are three values for accuracy variable TOL');
disp(' ');
disp('1. 10^-3');
disp('2. 10^-6');
disp('3. 10^-9');
while (choise3~=1)&(choise3~=2)&(choise3~=3)
choise3=input('Please select one: ');
end
end
if choise3==1
	mytol=1e-3;
elseif choise3==2
	mytol=1e-6;
else
	mytol=1e-9;
end

if choise2==1
exact1=fzero(f,x00, optimset('TolX',eps));
[a1,iter1,logerr1]=nr(f,df,x0,100,mytol,exact1);
[a2,iter2,logerr2]=nr2(f,1e-3,x0,100,mytol,exact1);
[a3,iter3,logerr3]=nr3(f,1e-3,x0,100,mytol,exact1);

fprintf('ex.1\nxct : %22.16f\nnr1 : %22.15f\nnr2 : %22.15f\nnr3 : %22.15f\n',exact1,a1,a2,a3);
fprintf('iter1: %d iter2: %d iter3: %d\n',iter1,iter2,iter3);
end

if choise2==2
exact1=fzero(f,x00, optimset('TolX',eps));
[a1,iter1,logerr1]=nr(f,df,x0,100,mytol,exact1);
[a2,iter2,logerr2]=nr2(f,1e-3,x0,100,mytol,exact1);
[a3,iter3,logerr3]=nr3(f,1e-3,x0,100,mytol,exact1); 
plot (logerr1,'m');
hold on;
plot (logerr2,'r');
plot (logerr3,'b');
hold off
end

if choise2==3
exact1=fzero(f,x00, optimset('TolX',eps));

for digits=1:11
	t0=clock;
	for i=1:1000
		[a1,iter1,dits]=nrb(f,df,x0,100,digits,exact1);
		end
timearray(digits)=etime(clock,t0);
digarray(digits)=dits;
end

plot (digarray,timearray,'m')
hold on

for digits=1:11
	t0=clock;
	for i=1:1000
		[a1,iter1,dits]=nr2b(f,1e-3,x0,100,digits,exact1);
		end
timearray(digits)=etime(clock,t0);
digarray(digits)=dits;
end

plot (digarray,timearray,'r')

for digits=1:11
	t0=clock;
	for i=1:1000
		[a1,iter1,dits]=nr3b(f,1e-3,x0,100,digits,exact1);
		end
timearray(digits)=etime(clock,t0);
digarray(digits)=dits;
end

plot (digarray,timearray,'b')

hold off
end
disp(' ');disp(' ');
disp('Do you want to exit:');
disp('');
disp('1.  No');
disp('2. Yes');
disp('');

while (repeatch~=1)&(repeatch~=2)
repeatch=input('Do you want to exit?:');
end

end
disp(' ');disp(' ');
disp('       ---  Thank you for trying me! ---')
disp('         2002 DKL (LookFWD@mail.ntua.gr)')