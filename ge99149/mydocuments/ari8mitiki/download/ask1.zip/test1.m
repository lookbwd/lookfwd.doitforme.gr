function f=test1(x)

% First test function for NR Method

am = 149;

f= - x.^51 + x.^50 + x - am / ( am + 10 );