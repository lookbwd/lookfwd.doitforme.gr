function [x,iter,logerr] = nr(f,df,x0,maxit,tol,exact)
% Root of f(x)=0 by Newton-Raphson's Method
% method terminates when relative change > tol
% or maxinmum number exceeds of iterations
if nargin < 3, fprintf('insufficient input\n'); break; end;
if nargin < 4, maxit = 100; end;
if nargin < 5, tol = eps; end;
x=x0; iter = 0; xdiff = inf;
%fprintf('k              x_k             rel.change\n')
while xdiff>tol
    iter = iter +1; xold = x;
    x = x - feval(f,x)/ feval(df,x);


    xdiff = abs(x-xold)/abs(x);
	logerr(iter) = -log10 (abs(x-exact));
%    fprintf('%2.0f:   %20.16e  %9.2e\n',iter,x,xdiff )
    if iter > maxit
        fprintf('Not coverged after %d iterations.', maxit);
        break;
    end
end