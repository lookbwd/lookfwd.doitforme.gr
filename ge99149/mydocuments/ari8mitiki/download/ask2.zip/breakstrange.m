function [di,u1,u3,d1,d3] = breakstrange(a)
% BREAKSTRANGE creates a sparse matrix as specified at part 1 of ex.2
% of numerical analysis laboratory
%
% S = CREATESPARSE(n,am) creates a n-by-n sparse matrix and am is defined
% by the three last digits of our university ID

di=diag(a,0);
u1=diag(a,1);
u3=diag(a,3);
d1=diag(a,-1);
d3=diag(a,-3);