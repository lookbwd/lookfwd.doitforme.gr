repeatch=0;
while (repeatch~=2)
repeatch=0;
choise1=0;

am=149;

disp('Wellcome to Exercise 2 of Numerical Analysis I');
disp('Created by Dimitris Kousis - Loucas 2002 (GE99149)');

disp(' ');disp(' ');disp(' ');
disp('There are three parts of the exercise');
disp('Which one would you like to run?');
disp(' ');
disp('1. LU Decomposition of sparse matrices  (0:45)');
disp('2. SOR Method on a sparse linear system (1:15)');
disp('3. JOR Method on a sparse linear system (3:20)');
while (choise1~=1)&(choise1~=2)&(choise1~=3)
choise1=input('Please select one: ');
end

if choise1==1
    nors=[500,200,40,20,10,8,6,4,2,1];
    
    for n=1:10
        fprintf('\nMeasuring time for LU decomposition of a %dx%d matrix\nby performing %3d repeat(s) :',n*100,n*100,nors(n));
        a=createsparse(n*100,am);
        t(n,1)=length(a);
    
        if issparse(a) fprintf('\t\t[sparse]'); else fprintf('\t\t[full]'); end;
    
    	tic;
        for i=1:nors(n) [c,d]=lu(a); end;
    	t(n,2)=toc/nors(n);

    	a=full(a);
    
        if issparse(a) fprintf('\t\t[sparse]'); else fprintf('\t\t[full]'); end;
    
    	tic;
        for i=1:nors(n) [c,d]=lu(a); end;
    	t(n,3)=toc/nors(n);
    end;
    
    fprintf('\nsize  sparce time(sec) full time(sec)\n');
    for n=1:10 fprintf('%4d%15.5f%15.5f\n',t(n,1),t(n,2),t(n,3)); end;
    plot(t(:,1),t(:,2),'r',t(:,1),t(:,3),'b');
end;







if choise1==2
    
[a,b]=createstrange;
[a1,a2,a3,a4,a5]=breakstrange(a);
clear data;
x0=ones(100,1);

for s=1:3
    for n=1:15,
        w=1 + 0.05 * (n-1) ;
        data(s,n,1)=w;
        fprintf('tol :%5.0e w :%5.2f [SOR]',1e-4^s,w);
        tic;
        [x,data(s,n,2),data(s,n,3)]=sor(a,b,x0,1e-4^s,w);
        data(s,n,4)=toc;
        fprintf('\t[Optimized SOR]\n');
        tic;
        [x,data(s,n,2),data(s,n,3)]=o_sor(a1,a2,a3,a4,a5,b,x0,1e-4^s,w);
        data(s,n,5)=toc;
    end;
end;

figure(1);
surf(data( 1,:,1 ), 1:3 , data( :,:,3 ) );
figure(2);
surf(data( 1,:,1 ),1:3 , data( :,:,2 ) );

figure(3);
surf(data( 1,:,1 ),1:3 , data( :,:,4 ) );
hold on;
surf(data( 1,:,1 ),1:3 , data( :,:,5 ) );
hold off;
    
end


if choise1==3

[a,b]=createstrange;
[a1,a2,a3,a4,a5]=breakstrange(a);
clear data;
x0=ones(100,1);

for s=1:3
    for n=1:13,
        w=1 + 0.05 * (n-1) ;
        data(s,n,1)=w;
        fprintf('tol :%5.0e w :%5.2f [JOR]',1e-4^s,w);
        tic;
        [x,data(s,n,2),data(s,n,3)]=jor(a,b,x0,1e-4^s,w);
        data(s,n,4)=toc;
        fprintf('\t[Optimized JOR]\n');
        tic;
        [x,data(s,n,2),data(s,n,3)]=o_jor(a1,a2,a3,a4,a5,b,x0,1e-4^s,w);
        data(s,n,5)=toc;
    end;
end;

figure(1);
surf(data( 1,:,1 ), 1:3 , data( :,:,3 ) );
figure(2);
surf(data( 1,:,1 ),1:3 , data( :,:,2 ) );

figure(3);
surf(data( 1,:,1 ),1:3 , data( :,:,4 ) );
hold on;
surf(data( 1,:,1 ),1:3 , data( :,:,5 ) );
hold off;

end;
    

disp(' ');disp(' ');
disp('Do you want to exit?');
disp('');
disp('1.  No');
disp('2. Yes');
disp('');

while (repeatch~=1)&(repeatch~=2)
repeatch=input('Please select one: ');
end

end
disp(' ');disp(' ');
disp('       ---  Thank you for trying me! ---')
disp('         2002 DKL (LookFWD@mail.ntua.gr)')