function a = createsparse(n,am)
% CREATESPARSE creates a sparse matrix as specified at part 1 of ex.2
% of numerical analysis laboratory
%
% S = CREATESPARSE(n,am) creates a n-by-n sparse matrix and am is defined
% by the three last digits of our university ID

if nargin < 1, fprintf('insufficient input\n'); break; end;
if nargin < 2, am=149; end;
% calculate ams from am
ams=am-10*floor(am/10);
% Diagonial's offset
plus=ams+50;
minus=-ams-20;
mindimension=max(abs(plus),abs(minus));
if mindimension>=n fprintf('dimention must be greater than %d\n',mindimension); break; end;
% Create matrix
a=diag([(am/(am+100))*ones(n,1)],0) +...
    diag((4*ones(n-abs(plus) ,1)),plus) + ...
    diag((3*ones(n-abs(minus),1)),minus);
a=sparse(a);

% This may not be the easiest way but it's a nice one
% Written by Dimitris Kousis Loukas 2002