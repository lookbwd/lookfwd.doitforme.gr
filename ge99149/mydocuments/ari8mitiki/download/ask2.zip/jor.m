function [x,k,infnorm]=JOR(a,b,x0,tol,w);
% method of JOR, for the solution of a sparse linear systerm a*x=b
% w represents the parameter � of the method

if nargin < 3, fprintf('insufficient input\n'); break; end;
if nargin == 3, tol=1.0e-6; w=1; end;
if nargin == 4, w=1; end;

n=length(b);

x=x0; xnew=zeros(n,1); k=0;

while max(abs(xnew-x))>tol & k<2000,

    x=xnew; k=k+1;
    
    for i=1:n,
        sum=0;
        for j=1:n
            if (j~=i)
                sum = sum + a(i,j) * x(j);
            end;
        end;
        xnew(i) = (1-w) * x(i) + ( w / a(i,i) ) * (b(i) - sum );

    end;

end;

x=xnew;

infnorm=norm(a*x-b,'inf');