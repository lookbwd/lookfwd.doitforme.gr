function [x,k,infnorm]=O_SOR(di,u1,u3,d1,d3,b,x0,tol,w);
% method of SOR optimized for sparse matrises, for the solution of a 
% sparse linear systerm a*x=b, w represents the parameter � of the method

if nargin < 7, fprintf('insufficient input\n'); break; end;
if nargin == 7, tol=1.0e-6; w=1; end;
if nargin == 8, w=1; end;

n=length(di);
if (length(u1)~=n-1)&(length(d1)~=n-1)&(length(u3)~=n-3)&(length(d3)~=n-3)...
        fprintf('error with matrix dimensions\n'); break; end;


x=x0; xnew=zeros(n,1); k=0;

while max(abs(xnew-x))>tol & k<2000,

    x=xnew; k=k+1;

        for i=1:n,
            sum1=0;  sum2=0;

                if (i-1 > 0) sum1=sum1+ d1(i-1)*xnew(i-1); end;
                if (i-3 > 0) sum1=sum1+ d3(i-3)*xnew(i-3); end;

                if (i+1 <= n) sum2=sum2+ u1(i)*x(i+1); end;
                if (i+3 <= n) sum2=sum2+ u3(i)*x(i+3); end;

            xnew(i) = (1-w) * x(i) + ( w / di(i) ) * (b(i) - sum1 - sum2 );
        end;
    end;

x=xnew;

loca=diag(di,0)+diag(u1,1)+diag(u3,3)+diag(d1,-1)+diag(d3,-3);

infnorm=norm(loca*x-b,'inf');