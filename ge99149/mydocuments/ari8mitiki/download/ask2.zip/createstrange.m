function [a,b] = createstrange(n,am,h);
% CREATESTRANGE creates a sparse matrix and a vector as specified at 
% part 2 of ex.2 of numerical analysis laboratory
%
% [A,B] = CREATESTRANGE(AM,N,H) am is the number defined by the three
% last digits of our university ID, h is the H parameter and n is the
% size of matrix. A is the sparse matrix and b is the vector. All pa-
% rameters are optional

if nargin < 1, am=149; end;
if nargin < 2, n=100; end;
if nargin < 3, h=0.1; end;

if n<1 fprintf('dimention must be greater than %d\n',mindimension); break; end;
% Create matrix
a=zeros(n);
for i=1:n, a(i,i)=4-h^2*f(i,am); end;
a=a + diag((-ones(n-1,1)),1) + ...
      diag((-ones(n-3,1)),3) + ...
      diag((-ones(n-1,1)),-1) + ...
      diag((-ones(n-3,1)),-3);

a=sparse(a);

for i=1:n, b(i)=0.01*i; end;
b=b';
  
function g = f(i,am);
g=-2*i*am;