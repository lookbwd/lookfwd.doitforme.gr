function varargout = interpolation(varargin)
% INTERPOLATION Application M-file for interpolation.fig
%    FIG = INTERPOLATION launch dialog GUI.
%    INTERPOLATION('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 02-Sep-2002 04:47:04

if nargin == 0  % LAUNCH GUI
	fig = openfig(mfilename,'reuse');
	% Use system color scheme for figure:
	set(fig,'Color',get(0,'defaultUicontrolBackgroundColor'));
	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);
	if nargout > 0
		varargout{1} = fig;
	end
elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK
	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end
end

% --------------------------------------------------------------------
%     These are callback functions used for handling gui's events
% --------------------------------------------------------------------

function varargout = m_a_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.m_b.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end
val = str2double(get(h,'String'));
if (~isnan(val)) & (isreal(val)) & ...
val >= get(handles.m_slider_a,'Min') & ...
val <= get(handles.m_slider_a,'Max')
set(handles.m_slider_a,'Value',val);
end
Redraw(handles);

% --------------------------------------------------------------------
function varargout = m_b_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.m_a.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end
val = str2double(get(h,'String'));
if (~isnan(val)) & (isreal(val)) & ...
val >= get(handles.m_slider_b,'Min') & ...
val <= get(handles.m_slider_b,'Max')
set(handles.m_slider_b,'Value',val);
end
Redraw(handles);

% --------------------------------------------------------------------
function varargout = radiobutton1_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.radiobutton1.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end
set(handles.r1,'value',1);
set(handles.r2,'value',0);
set(handles.m_h,'visible','off');
set(handles.m_h_label,'visible','off');
Redraw(handles);

% --------------------------------------------------------------------
function varargout = radiobutton2_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.radiobutton2.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end
set(handles.r1,'value',0);
set(handles.r2,'value',1);
set(handles.m_h,'visible','on');
set(handles.m_h_label,'visible','on');
Redraw(handles);

% --------------------------------------------------------------------
function varargout = pushbutton2_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.pushbutton2.
delete(gcf);

% --------------------------------------------------------------------
function varargout = pushbutton3_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.pushbutton3.
[iconData iconCmap] = imread('smalllogo.bmp');
message(1)={'Hermite Interpolation Final Edition'};
message(2)={'Copyright � 2002 DKL Software Engineering'};
message(3)={'For Numerical Analysis I Lesson 2002'};
message(4)={'http://users.ntua.gr/ge99149'};
d = msgbox(message,'About Hermite Interpolation','custom',iconData,iconCmap);
waitfor(d);

% --------------------------------------------------------------------
function varargout = m_slider_a_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.m_slider_a.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end

sliderValue=get(h,'value');
set(handles.m_a,'string',num2str(sliderValue));
Redraw(handles);

% --------------------------------------------------------------------
function varargout = m_slider_b_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.m_slider_b.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end

sliderValue=get(h,'value');
set(handles.m_b,'string',num2str(sliderValue));
Redraw(handles);

% --------------------------------------------------------------------
function varargout = ams_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.ams.
if (length(handles)==0)
    handles = guihandles(gcbo);
	guidata(gcbo, handles);
end
Redraw(handles);

% --------------------------------------------------------------------
function varargout = m_b_CreateFcn(h, eventdata, handles, varargin)
% Stub for CreateFcn of the uicontrol handles.m_b.

% Warning: Initial draw in this object because it's one of the last
% being created (in order to exist objects that Redraw uses)
% handles structure hasn't been created yet so use temporary handles
    temphandles = guihandles(gcbo);
    Redraw(temphandles);

% --------------------------------------------------------------------
%   These are some gui support functions that make everything easier
% --------------------------------------------------------------------
 
function fast = fastDrawLine(xData,yData,Color,Style,Tag)
sline = findobj('Tag',Tag);
if (length(sline)==0)
    sline = line('XData',xData,'YData',yData,'Color',Color,...
        'LineStyle',Style,'Tag',Tag);
else
    set(sline,'XData',xData,'YData',yData);
end

% --------------------------------------------------------------------
function fast = fastDrawText(x,y,string,Color,Tag)
stext = findobj('Tag',Tag);
if (length(stext)==0)
    stext = text(x,y,string,'Color',Color,'VerticalAlignment','Top'...
        ,'FontSize',8,'Tag',Tag);
else
    set(stext,'String',string,'Position',[x y 0]);
end

% --------------------------------------------------------------------
function ans = getDataFromEditHandle(handle,min,max,default,name)
ans = str2double(get(handle,'string'));
if (isnan(ans))
    ans=default;
    d = warndlg(['Warning '  name ' must be number. Setting to default '...
        num2str(default)],'Warning','modal');
    waitfor(d);
    set(handle,'string',num2str(default));
end
if (~isreal(ans))
    ans = default;
    d = warndlg(['Warning '  name ' must not be complex. Setting to default '...
        num2str(default)],'Warning','modal');
    waitfor(d);
    set(handle,'string',num2str(default));
end
if (( ans > max ) | ( ans < min ))
    ans=default;
    d = warndlg(['Warning ' name ' must be between ' num2str(min)...
        ' and ' num2str(max) '. Setting to default ' num2str(default)],...
        'Warning','modal');
    waitfor(d);
    set(handle,'string',num2str(default));
end

% --------------------------------------------------------------------
%          This is the main routine that calculates everything
%               and present the results to the graphs
% --------------------------------------------------------------------

function varargout = Redraw(handles)

%                  Input variables and Validation

localAms = getDataFromEditHandle(handles.ams,0,9,9,'ams');
localH = getDataFromEditHandle(handles.m_h,1e-8,0.499999,0.001,'h');
method = (get(handles.r1,'value')==get(handles.r1,'max'));

% --------------------------------------------------------------------
%                      Calculations segment
% --------------------------------------------------------------------

% calculate x(s) coefficients with one of two methods and store at px
x0= 0 ;
x1= 1 ;
f0= 1 ;
f1= 4 + localAms;
ff0= getDataFromEditHandle(handles.m_a, -1e20 , 1e20 , 0 ,'a' );
ff1= 0 ;

if (method)
px = Hermite( x0, x1, f0, f1, ff0, ff1);
else
px = Lagrange(x0, x1, f0, f1, ff0, ff1, localH);
end

refx = Hermite( x0, x1, f0, f1, ff0, ff1);

% calculate y(s) coefficients with one of two methods and store at py

f0= 1 ;
f1= 2 + localAms;
ff0= 0;
ff1= getDataFromEditHandle(handles.m_b, -1e20 , 1e20 , 0 ,'b' );

if (method)
py = Hermite( x0, x1, f0, f1, ff0, ff1);
else
py = Lagrange(x0, x1, f0, f1, ff0, ff1, localH);
end

refy = Hermite( x0, x1, f0, f1, ff0, ff1);

% calculate norm values
norx = sum(((px - refx).^2)).^0.5;
nory = sum(((py - refy).^2)).^0.5;

% calculate 21 sample values for graphs
i = 0:0.05:1;
j = polyval(px , i);
k = polyval(py , i);

% --------------------------------------------------------------------
%                       Real graphics segment
% --------------------------------------------------------------------

% calculate min/max values for graph
maxx = max(j);
maxy = max(k);
minx = min(j);
miny = min(k);
ybase = min(minx,miny) - 1;
yscope = max(maxx,maxy) - min(minx,miny) + 2;

% prepare strings for graph
texta = ['x(s) = ' num2str(px(1)) ' s^3 + ' num2str(px(2)) ...
   ' s^2 + ' num2str(px(3)) ' s + ' num2str(px(4)) ];
textb = ['y(s) = ' num2str(py(1)) ' s^3 + ' num2str(py(2)) ...
    ' s^2 + ' num2str(py(3)) ' s + ' num2str(py(4)) ];

% print two polynomials to the command line
fprintf('x(s) = %9.4f s^3 + %9.4f s^2 + %9.4f s + %9.4f\n',px(1),px(2),px(3),px(4));
fprintf('y(s) = %9.4f s^3 + %9.4f s^2 + %9.4f s + %9.4f\n',py(1),py(2),py(3),py(4));

% print error (norm) values to the command line
disp(['error(x) = ' num2str(norx)]);
disp(['error(y) = ' num2str(nory)]);


% plot to axes x(s) y(s) and finaly y(x)

axes(handles.m_s_axes);
fastDrawLine([0 1],[1 1],[0.77 0.77 0.77],'--','horARule');
fastDrawLine([0 1],[4 + localAms 4 + localAms],[0.77 0.77 0.77],'--','horBRule');
fastDrawText(0.05,(ybase + 0.99 * yscope),texta,'b','texta');
fastDrawText(0.05,(ybase + 0.93 * yscope),textb,'r','textb');
fastDrawLine(i,j,'b','-','xsline');
fastDrawLine(i,k,'r','-','ysline');
set(handles.m_s_axes,'YLim',[(min(minx,miny)-1) (1 + max(maxx,maxy))]);


axes(handles.m_xy_axes);
fastDrawLine(j,k,'m','-','xyline');
fastDrawLine([minx-1 maxx+1],[1 1],[0.77 0.77 0.77],'--','horRule');
fastDrawLine([4 + localAms 4 + localAms],[miny-1 maxy+1],...
    [0.77 0.77 0.77],'--','verRule');
set(handles.m_xy_axes,'XLim',[(minx-1) (1 + maxx)]);
set(handles.m_xy_axes,'YLim',[(miny-1) (1 + maxy)]);

% --------------------------------------------------------------------
%              These are the two interpolation methods
% --------------------------------------------------------------------

function herm = Hermite(x0, x1, f0, f1, ff0, ff1)

x=[x0, ((x1-x0)/3), (2*(x1-x0)/3), x1];

for i=1:4
H0=(1-2*((x(i)-x0)/(x0-x1)))*(( ((x(i)-x1)/(x0-x1)) ) ^ 2);
H1=(1-2*((x(i)-x1)/(x1-x0)))*(( ((x(i)-x0)/(x1-x0)) ) ^ 2);
HH0=(x(i)-x0)*(( ((x(i)-x1)/(x0-x1)) ) ^ 2);
HH1=(x(i)-x1)*(( ((x(i)-x0)/(x1-x0)) ) ^ 2);

HermShot(i) = f0 * H0 + f1 * H1 + ff0 * HH0 + ff1 * HH1;
end

van = (vander(x))';
herm = HermShot / van;


% --------------------------------------------------------------------
function Lagr = Lagrange(x0, x1, f0, f1, ff0, ff1, h)
xPoints=[x0,   x0+h      ,    x1-h      ,     x1];
yPoints=[f0,   f0+(h*ff0),    f1-(h*ff1),     f1];
Lagr = polyfit(xPoints,yPoints,3);