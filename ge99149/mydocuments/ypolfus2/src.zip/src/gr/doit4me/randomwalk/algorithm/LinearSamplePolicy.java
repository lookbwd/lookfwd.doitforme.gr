package gr.doit4me.randomwalk.algorithm;

public class LinearSamplePolicy
    extends SamplePolicy {
  private int min = 5;
  private int max = 20000;
  private int steps = 25;

  public LinearSamplePolicy() {
  }

  public SamplePolicy getCopy() {
    LinearSamplePolicy p = new LinearSamplePolicy ();
    p.min = min;
    p.max = max;
    p.steps = steps;
    return p;
  }

  public String getDescription() {
    return "Linear distribution";
  }

  public void setMin(int min) {
    this.min = min;
  }

  public void setMax(int max) {
    this.max = max;
  }

  public void setSteps(int steps) {
    if (steps <= 2) {
      return;
    }
    this.steps = steps;
  }

  public int getCursor(int i) {
    return (int) Math.floor( (double) i *
                            ( ( (double) (max - min)) / (steps - 1))) + min;
  }
  public int getMax() {
    return max;
  }
  public int getMin() {
    return min;
  }
  public int getSteps() {
    return steps;
  }
}