package gr.doit4me.randomwalk.data;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.event.TreeModelListener;

public class SimulationTreeModel
    implements TreeModel {
  Simulation simulation;

  public SimulationTreeModel(Simulation metaPathPack) {
    this.simulation = metaPathPack;
  }

  public Object getRoot() {
    return simulation;
  }

  public Object getChild(Object parent, int index) {
    if (parent == simulation) {
      return (simulation.getMetaPathPack())[index];
    }
    if (parent instanceof Run) {
      return ( ( (Run) parent).getPack())[index];
    }
    return null;
  }

  public int getChildCount(Object parent) {
    if (parent == simulation) {
      return (simulation.getMetaPathPack()).length;
    }
    if (parent instanceof Run) {
      return ( ( (Run) parent).getPack()).length;
    }
    return -1;
  }

  public boolean isLeaf(Object node) {
    if (node instanceof Run|| node == simulation) {
      if (node instanceof Run) {
        return ( ( (Run) node).getPack().length == 0);
      }
      else {
        return simulation.getMetaPathPack().length == 0;
      }
    }
    return true;
  }

  public int getIndexOfChild(Object parent, Object child) {
    if (parent == simulation) {
      Run[] pack = simulation.getMetaPathPack();
      for (int i = 0; i < pack.length; i++) {
        if (pack[i] == child) {
          return i;
        }
      }
    }
    if (parent instanceof Run) {
      Measure[] pack = ( (Run) parent).getPack();
      for (int i = 0; i < pack.length; i++) {
        if (pack[i] == child) {
          return i;
        }
      }
    }
    return -1;
  }

  public void addTreeModelListener(TreeModelListener l) {
  }

  public void removeTreeModelListener(TreeModelListener l) {
  }

  public void valueForPathChanged(TreePath path, Object newValue) {
  }
}