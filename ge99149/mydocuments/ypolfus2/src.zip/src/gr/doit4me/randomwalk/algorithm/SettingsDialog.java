package gr.doit4me.randomwalk.algorithm;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

public class SettingsDialog
    extends JDialog {
  private Settings settings = null;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JTextField stepsmax = new JTextField();
  GridLayout gridLayout2 = new GridLayout();
  JPanel panel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  TitledBorder titledBorder1;
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JButton btCancel = new JButton();
  JButton btOK = new JButton();
  JPanel jPanel7 = new JPanel();
  JTextField walksCount = new JTextField();
  JLabel jLabel2 = new JLabel();
  GridLayout gridLayout3 = new GridLayout();
  GridLayout gridLayout4 = new GridLayout();
  GridLayout gridLayout6 = new GridLayout();
  JLabel jLabel3 = new JLabel();
  JTextField stepsmin = new JTextField();
  JLabel jLabel4 = new JLabel();
  GridLayout gridLayout5 = new GridLayout();
  JTextField stepsNumber = new JTextField();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel12 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel9 = new JPanel();
  GridLayout gridLayout7 = new GridLayout();
  JLabel jLabel5 = new JLabel();
  JCheckBox jHoldData = new JCheckBox();
  JPanel jPanel10 = new JPanel();
  JCheckBox jdo3D = new JCheckBox();
  GridLayout gridLayout8 = new GridLayout();
  JLabel jLabel6 = new JLabel();
  JPanel jPanel11 = new JPanel();
  GridLayout gridLayout9 = new GridLayout();
  JLabel jLabel7 = new JLabel();
  JComboBox sampleDistr = new JComboBox(SamplePolicy.getOptions());

  public SettingsDialog(Frame frame) {
    super(frame, "Simulation options", true);
    try {
      jbInit();
      pack();
      centerDialog();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public SettingsDialog(Frame frame, Settings settings) {
    this(frame);
    if (settings != null) {
      SamplePolicy policy = settings.getPolicy();
      if (policy!=null) {
        stepsmax.setText(String.valueOf(policy.getMax()));
        stepsmin.setText(String.valueOf(policy.getMin()));
        stepsNumber.setText(String.valueOf(policy.getSteps()));
        for (int i = 0; i < sampleDistr.getItemCount(); i++) {
          if (sampleDistr.getItemAt(i).toString().equals(policy.getDescription())) {
            sampleDistr.setSelectedIndex(i);
          }
        }
      }
      walksCount.setText(String.valueOf(settings.getRepeats()));
      jHoldData.setSelected(settings.isHoldIdivindual());
      jdo3D.setSelected(settings.isDo3D());
      jHoldData.setEnabled(!settings.isDo3D());
    }
  }

  public Settings getSettings() {
    return settings;
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(148, 145, 140)), "Simulation Settings:");
    jPanel1.setLayout(borderLayout1);
    jPanel4.setLayout(gridLayout2);
    gridLayout1.setRows(7);
    jLabel1.setText("Maximum number of steps for path:");
    gridLayout2.setColumns(2);
    gridLayout2.setRows(1);
    panel1.setLayout(gridLayout1);
    panel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setLayout(borderLayout2);
    btCancel.setText("Cancel");
    btCancel.addActionListener(new SettingsDialog_btCancel_actionAdapter(this));
    btOK.setText("OK");
    stepsmax.setText("20000");
    stepsmax.setHorizontalAlignment(SwingConstants.TRAILING);
    jPanel7.setLayout(gridLayout3);
    walksCount.setText("1000");
    walksCount.setHorizontalAlignment(SwingConstants.TRAILING);
    jLabel2.setText("Number of repeats:");
    gridLayout3.setColumns(2);
    gridLayout3.setRows(1);
    jPanel3.setLayout(gridLayout4);
    gridLayout4.setColumns(2);
    jPanel2.setLayout(gridLayout6);
    gridLayout6.setColumns(2);
    jLabel3.setText("Minimum number of steps for path:");
    stepsmin.setText("5");
    stepsmin.setHorizontalAlignment(SwingConstants.TRAILING);
    jLabel4.setText("Number of steps:");
    gridLayout5.setRows(1);
    gridLayout5.setColumns(2);
    stepsNumber.setHorizontalAlignment(SwingConstants.TRAILING);
    stepsNumber.setText("25");
    jPanel8.setLayout(gridLayout5);
    jPanel12.setLayout(borderLayout3);
    jPanel9.setLayout(gridLayout7);
    gridLayout7.setColumns(2);
    jLabel5.setText("Store path data (slow, much memory):");
    jHoldData.setText("Store");
    jPanel10.setLayout(gridLayout8);
    jdo3D.setText("3D simulation");
    jdo3D.addActionListener(new SettingsDialog_jdo3D_actionAdapter(this));
    gridLayout8.setColumns(2);
    jLabel6.setText("Perform 3D simulation:");
    jPanel11.setLayout(gridLayout9);
    gridLayout9.setColumns(2);
    jLabel7.setText("Sample distribution:");
    this.getContentPane().add(jPanel12, BorderLayout.CENTER);
    jPanel12.add(jPanel1, BorderLayout.CENTER);
    jPanel12.add(jPanel5, BorderLayout.SOUTH);
    jPanel1.add(panel1, BorderLayout.CENTER);
    jPanel4.add(jLabel1, null);
    jPanel4.add(stepsmax, null);
    jPanel8.add(jLabel4, null);
    jPanel8.add(stepsNumber, null);
    jPanel10.add(jLabel6, null);
    jPanel10.add(jdo3D, null);
    jPanel11.add(jLabel7, null);
    jPanel11.add(sampleDistr, null);
    panel1.add(jPanel2, null);
    panel1.add(jPanel4, null);
    panel1.add(jPanel8, null);
    panel1.add(jPanel11, null);
    panel1.add(jPanel3, null);
    panel1.add(jPanel9, null);
    panel1.add(jPanel10, null);
    jPanel3.add(jPanel7, null);
    jPanel7.add(jLabel2, null);
    jPanel7.add(walksCount, null);
    jPanel9.add(jLabel5, null);
    jPanel9.add(jHoldData, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(stepsmin, null);
    jPanel5.add(jPanel6, BorderLayout.EAST);
    jPanel6.add(btOK, null);
    jPanel6.add(btCancel, null);
    btOK.addActionListener(new SettingsDialog_btOK_actionAdapter(this));
    this.getRootPane().setDefaultButton(btOK);
  }

  protected void centerDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation( (screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);
  }

  public static Settings showDialog(Frame frame) {
    SettingsDialog dlg = new SettingsDialog(frame);
    dlg.show();
    return dlg.getSettings();
  }

  public static Settings showDialog(Frame frame, Settings settings) {
    SettingsDialog dlg = new SettingsDialog(frame, settings);
    dlg.show();
    return dlg.getSettings();
  }

  void btCancel_actionPerformed(ActionEvent e) {
    dispose();
  }

  void btOK_actionPerformed(ActionEvent e) {
    int stepmin;
    int stepmax;
    int repeats;
    int steps;
    try {
      if ( (stepmin = Integer.valueOf(stepsmin.getText()).intValue()) <= 0) {
        throw new NumberFormatException();
      }
    }
    catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,
          "Steps minimum number must be a valid positive integer.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
      return;
    }
    try {
      if ( (stepmax = Integer.valueOf(stepsmax.getText()).intValue()) <= 0) {
        throw new NumberFormatException();
      }
    }
    catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,
          "Steps maximum number must be a valid positive integer.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (stepmax <= stepmin) {
      JOptionPane.showMessageDialog(this,
          "Maximum step number must be greater than minimum step number.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
      return;
    }
    try {
      if ( (repeats = Integer.valueOf(walksCount.getText()).intValue()) <= 0) {
        throw new NumberFormatException();
      }
    }
    catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,
                                    "Walks must be a valid positive integer.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
      return;
    }
    try {
      if ( (steps = Integer.valueOf(stepsNumber.getText()).intValue()) <= 0) {
        throw new NumberFormatException();
      }
    }
    catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,
                                    "Steps must be a valid positive integer.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (steps * repeats > 1500 && jHoldData.isSelected()) {
      JOptionPane.showMessageDialog(this, "Too many steps - walks selected. Please select smaller numbers or disable Store of path data",
                                    "Error", JOptionPane.ERROR_MESSAGE);
      return;
    }
    settings = new Settings();
    SamplePolicy policy = SamplePolicy.getInstance(sampleDistr.getSelectedItem().toString());
    if (policy!=null) {
      policy.setMin(stepmin);
      policy.setMax(stepmax);
      policy.setSteps(steps);
      settings.setPolicy(policy);
    }
    settings.setRepeats(repeats);
    settings.setHoldIdivindual(jHoldData.isSelected());
    settings.setDo3D(jdo3D.isSelected());
    dispose();
  }

  void jdo3D_actionPerformed(ActionEvent e) {
    if (jdo3D.isSelected()) {
      jHoldData.setSelected(false);
      jHoldData.setEnabled(false);
    }
    else {
      jHoldData.setEnabled(true);
    }
  }
}

class SettingsDialog_btCancel_actionAdapter
    implements java.awt.event.ActionListener {
  SettingsDialog adaptee;

  SettingsDialog_btCancel_actionAdapter(SettingsDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btCancel_actionPerformed(e);
  }
}

class SettingsDialog_btOK_actionAdapter
    implements java.awt.event.ActionListener {
  SettingsDialog adaptee;

  SettingsDialog_btOK_actionAdapter(SettingsDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btOK_actionPerformed(e);
  }
}

class SettingsDialog_jdo3D_actionAdapter
    implements java.awt.event.ActionListener {
  SettingsDialog adaptee;

  SettingsDialog_jdo3D_actionAdapter(SettingsDialog adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jdo3D_actionPerformed(e);
  }
}