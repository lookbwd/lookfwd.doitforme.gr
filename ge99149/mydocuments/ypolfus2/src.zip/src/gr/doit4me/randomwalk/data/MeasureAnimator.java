package gr.doit4me.randomwalk.data;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MeasureAnimator
    extends JComponent
    implements ActionListener {
  Measure path;
  MeasureView view = new MeasureView ();
  int step;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel mainPanel = new JPanel();
  TitledBorder titledBorder1;
  Timer timer = new Timer(20, this);
  JPanel jPanel1 = new JPanel();
  JCheckBox forward = new JCheckBox();
  JCheckBox animateCheck = new JCheckBox();
  JPanel jPanel2 = new JPanel();
  JButton btPrev = new JButton();
  JButton btEND = new JButton();
  JButton btBegin = new JButton();
  JButton btNext = new JButton();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel3 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel infoLabel = new JLabel();

  public MeasureAnimator() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Measure getPath() {
    return path;
  }

  public void setPath(Measure path) {
    this.path = path;
    boolean visual = path != null && path.getPointCount() > 1;
    setButtonEnabled(visual);

    if (visual) {
      moveToEnd();
    }
    else {
      showPath();
    }
    infoLabel.setEnabled(path != null);
    if (path != null) {
      infoLabel.setText("Final radius: " + (Math.floor(path.getR() * 100) / 100) +
                        "  Maximum radius: " +
                        (Math.floor(path.getRm() * 100) / 100));
    }
    else {
      infoLabel.setText("No info available.");
    }
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(178, 178, 178)), "Random walk View");
    this.setLayout(borderLayout1);
    view.setBorder(titledBorder1);
    mainPanel.setLayout(borderLayout2);
    forward.setEnabled(false);
    forward.setSelected(true);
    forward.setText("Forward");
    animateCheck.setEnabled(false);
    animateCheck.setText("Animate");
    animateCheck.addActionListener(this);
    btPrev.setEnabled(false);
    btPrev.setText("<");
    btPrev.addActionListener(this);
    btEND.setEnabled(false);
    btEND.setText(">>");
    btEND.addActionListener(this);
    btBegin.setEnabled(false);
    btBegin.setText("<<");
    btBegin.addActionListener(this);
    btNext.setEnabled(false);
    btNext.setText(">");
    btNext.addActionListener(this);
    mainPanel.setBorder(null);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setLayout(gridLayout1);
    infoLabel.setBorder(BorderFactory.createEtchedBorder());
    infoLabel.setText(" ");
    jPanel2.add(btBegin, null);
    jPanel1.add(animateCheck, null);
    this.add(view, BorderLayout.CENTER);
    this.add(mainPanel, BorderLayout.SOUTH);

    mainPanel.add(jPanel1, BorderLayout.EAST);
    jPanel1.add(forward, null);
    mainPanel.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(btPrev, null);
    jPanel2.add(btNext, null);
    jPanel2.add(btEND, null);
    mainPanel.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(infoLabel, null);
  }

  private void setButtonEnabled(boolean state) {
    forward.setEnabled(state);
    animateCheck.setEnabled(state);
    btPrev.setEnabled(state);
    btEND.setEnabled(state);
    btBegin.setEnabled(state);
    btNext.setEnabled(state);
  }

  private void showPath() {
    view.setPath(path.subPath(step));
  }

  public synchronized void moveToBeginning() {
    animateCheck.setSelected(false);
    timer.stop();
    step = 2;
    showPath();
  }

  public synchronized void moveToEnd() {
    animateCheck.setSelected(false);
    timer.stop();
    step = path.getPointCount() + 1;
    showPath();
  }

  public synchronized void nextStep() {
    animateCheck.setSelected(false);
    timer.stop();
    if (step <= path.getPointCount()) {
      step++;
      showPath();
    }
  }

  public synchronized void previousStep() {
    animateCheck.setSelected(false);
    timer.stop();
    if (step > 2) {
      step--;
      showPath();
    }
  }

  public synchronized void startAnimation() {
    showPath();
    timer.start();
  }

  public synchronized void stopAnimation() {
    timer.stop();
  }

  public void actionPerformed(ActionEvent actionEvent) {
    Object a = actionEvent.getSource();
    if (a == btEND) {
      moveToEnd();
    }
    if (a == btNext) {
      nextStep();
    }
    if (a == btPrev) {
      previousStep();
    }
    if (a == btBegin) {
      moveToBeginning();
    }
    if (a == timer) {
      if (forward.isSelected()) {
        if (step <= path.getPointCount()) {
          step++;
          showPath();
        }
      }
      else {
        if (step > 2) {
          step--;
          showPath();
        }
      }
    }
    if (a == animateCheck) {
      if (animateCheck.isSelected()) {
        if (!timer.isRunning()) {
          timer.start();
        }
      }
      else {
        if (timer.isRunning()) {
          timer.stop();
        }
      }
    }
  }
}