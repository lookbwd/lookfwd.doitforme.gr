package gr.doit4me.randomwalk.algorithm;

public class ExpSamplePolicy extends SamplePolicy {
  private int min = 5;
  private int max = 20000;
  private int steps = 25;
  private double alpha;

  public ExpSamplePolicy() {
    calculateAlpha();
  }

  public SamplePolicy getCopy() {
    ExpSamplePolicy p = new ExpSamplePolicy ();
    p.min = min;
    p.max = max;
    p.steps = steps;
    p.alpha = alpha;
    return p;
  }

  public String getDescription() {
    return "Exponential distribution";
  }

  public void setMin(int min) {
    this.min = min;
    calculateAlpha();
  }

  public void setMax(int max) {
    this.max = max;
    calculateAlpha();
  }

  public void setSteps(int steps) {
    if (steps <= 2) {
      return;
    }
    this.steps = steps;
    calculateAlpha();
  }

  private void calculateAlpha() {
    alpha = ((double)(steps-1)) / Math.log(1 + ((double) (max - min)) );
  }

  public int getCursor(int i) {
    return (int) Math.floor(Math.exp(i/alpha) + min);
  }
  public int getMax() {
    return max;
  }
  public int getMin() {
    return min;
  }
  public int getSteps() {
    return steps;
  }
}