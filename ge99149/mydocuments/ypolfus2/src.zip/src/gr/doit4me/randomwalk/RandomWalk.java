package gr.doit4me.randomwalk;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.BorderLayout;
import javax.swing.border.*;
import gr.doit4me.randomwalk.data.*;
import gr.doit4me.randomwalk.algorithm.*;
import java.io.File;
import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.*;
import java.beans.XMLDecoder;

public class RandomWalk
    extends JFrame {
  JPanel contentPane;
  JMenuBar menuBar = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenuItem jMenuFileExit = new JMenuItem();
  JMenu jMenuHelp = new JMenu();
  JMenuItem jMenuHelpAbout = new JMenuItem();
  BorderLayout borderLayout1 = new BorderLayout();
  SimulationExplorer view = new SimulationExplorer ();
  TitledBorder titledBorder1;
  RandomWalkAlgorithm algorithm = new DefaultRandomWalkAlgorithm ();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem loadSim = new JMenuItem();
  JMenuItem saveSim = new JMenuItem();
  JFileChooser chooser = new JFileChooser();
  Simulation metaPathPack = new Simulation ();
  JMenuItem jMenuItem2 = new JMenuItem();

  //Construct the frame
  public RandomWalk() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      pack();
      centerDialog();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(178, 178, 178)), "Random walk view");
    contentPane.setLayout(borderLayout1);
    jMenuItem1.setText("New simulation");
    jMenuItem1.addActionListener(new RandomWalk_jMenuItem1_actionAdapter(this));
    saveSim.setText("Save simulation data");
    saveSim.addActionListener(new RandomWalk_saveSim_actionAdapter(this));
    loadSim.setText("Load simulation data");
    loadSim.addActionListener(new RandomWalk_loadSim_actionAdapter(this));
    jMenuItem2.setText("Spreadsheet export");
    jMenuItem2.addActionListener(new RandomWalk_jMenuItem2_actionAdapter(this));
    contentPane.add(view, BorderLayout.CENTER);
    this.setTitle("Random Walker 2003");
    jMenuFile.setText("File");
    jMenuFileExit.setText("Exit");
    jMenuFileExit.addActionListener(new RandomWalk_jMenuFileExit_ActionAdapter(this));
    jMenuHelp.setText("Help");
    jMenuHelpAbout.setText("About");
    jMenuHelpAbout.addActionListener(new
                                     RandomWalk_jMenuHelpAbout_ActionAdapter(this));
    jMenuFile.add(jMenuItem1);
    jMenuFile.add(saveSim);
    jMenuFile.add(loadSim);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuItem2);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileExit);
    jMenuHelp.add(jMenuHelpAbout);
    menuBar.add(jMenuFile);
    menuBar.add(jMenuHelp);
    this.setJMenuBar(menuBar);
  }

  protected void centerDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation( (screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2);
  }

  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  //Help | About action performed
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    view.showLogo();
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }

  public static void main(String[] argv) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    RandomWalk frame = new RandomWalk();
    frame.show();
  }

  void jMenuItem1_actionPerformed(ActionEvent e) {
    Settings set = SettingsDialog.showDialog(this, metaPathPack.getSettings());
    if (set != null) {
      metaPathPack.setSettings(set);
      (new Thread() {
        public void run() {
          metaPathPack = algorithm.doWalk(metaPathPack);
          view.setMetaPathPack(metaPathPack);
        }
      }).start();
    }
  }

  void saveSim_actionPerformed(ActionEvent e) {
    chooser.setFileFilter(new XMLFileFilter());
    if (metaPathPack != null &&
        chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      (new Thread() {
        public void run() {
          File f = chooser.getSelectedFile();
          if (f.getAbsolutePath().toLowerCase().endsWith(".xml") == false) {
            f = new File(f.getAbsolutePath() + ".xml");
          }
          try {
            XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(new
                FileOutputStream(f)));
            encoder.writeObject(metaPathPack);
            encoder.close();
            JOptionPane.showMessageDialog(null, "Save operation successful.");
          }
          catch (FileNotFoundException ex) {
          }
        }
      }).start();
    }
  }

  void loadSim_actionPerformed(ActionEvent e) {
    chooser.setFileFilter(new XMLFileFilter());
    if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      (new Thread() {
        public void run() {
          File f = chooser.getSelectedFile();
          try {
            XMLDecoder encoder = new XMLDecoder(new BufferedInputStream(
                new ProgressMonitorInputStream(null,
                                               "Loading file " + f.getName(),
                                               new FileInputStream(f))));
            metaPathPack = (Simulation) encoder.readObject();
            encoder.close();
            view.setMetaPathPack(metaPathPack);
          }
          catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error loading file.");
            ex.printStackTrace(System.err);
          }
        }
      }).start();
    }
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    chooser.setFileFilter(new OutFileFilter());
    if (metaPathPack != null &&
        chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      File f = chooser.getSelectedFile();
      if (f.getAbsolutePath().toLowerCase().endsWith(".txt") == false) {
        f = new File(f.getAbsolutePath() + ".txt");
      }
      try {
        FileWriter out = new FileWriter(f);
        out.write("t\t" +
                  "r^2\t" +
                  "dr^2\t" +
                  "rm^2\t" +
                  "drm^2\t" +
                  "time\r\n");
        Run[] pack = metaPathPack.getMetaPathPack();
        for (int i = 0; i < pack.length; i++) {
          out.write(trimToSecondDecimal(pack[i].getNumberOfSteps()) + "\t" +
                    trimToSecondDecimal(pack[i].getRavv()) + "\t" +
                    trimToSecondDecimal(pack[i].getDeltaRavv()) + "\t" +
                    trimToSecondDecimal(pack[i].getRmAvv()) + "\t" +
                    trimToSecondDecimal(pack[i].getDeltaRmavv()) + "\t" +
                    trimToSecondDecimal(pack[i].getTime()) + "\r\n");
        }
        out.close();
      }
      catch (IOException ex) {
      }

    }
  }

  private double trimToSecondDecimal(double in) {
    return Math.floor(in * 100) / 100;
  }
}

final class XMLFileFilter
    extends javax.swing.filechooser.FileFilter {

  public boolean accept(File f) {
    return f.getName().toLowerCase().endsWith(".xml") || f.isDirectory();
  }

  public String getDescription() {
    return "XML file (*.xml)";
  }
}

final class OutFileFilter
    extends javax.swing.filechooser.FileFilter {

  public boolean accept(File f) {
    return f.getName().toLowerCase().endsWith(".txt") || f.isDirectory();
  }

  public String getDescription() {
    return "Text file (*.txt)";
  }
}


class RandomWalk_jMenuFileExit_ActionAdapter
    implements ActionListener {
  RandomWalk adaptee;

  RandomWalk_jMenuFileExit_ActionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuFileExit_actionPerformed(e);
  }
}

class RandomWalk_jMenuHelpAbout_ActionAdapter
    implements ActionListener {
  RandomWalk adaptee;

  RandomWalk_jMenuHelpAbout_ActionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuHelpAbout_actionPerformed(e);
  }
}

class RandomWalk_jMenuItem1_actionAdapter
    implements java.awt.event.ActionListener {
  RandomWalk adaptee;

  RandomWalk_jMenuItem1_actionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem1_actionPerformed(e);
  }
}

class RandomWalk_saveSim_actionAdapter
    implements java.awt.event.ActionListener {
  RandomWalk adaptee;

  RandomWalk_saveSim_actionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.saveSim_actionPerformed(e);
  }
}

class RandomWalk_loadSim_actionAdapter
    implements java.awt.event.ActionListener {
  RandomWalk adaptee;

  RandomWalk_loadSim_actionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.loadSim_actionPerformed(e);
  }
}

class RandomWalk_jMenuItem2_actionAdapter
    implements java.awt.event.ActionListener {
  RandomWalk adaptee;

  RandomWalk_jMenuItem2_actionAdapter(RandomWalk adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem2_actionPerformed(e);
  }
}