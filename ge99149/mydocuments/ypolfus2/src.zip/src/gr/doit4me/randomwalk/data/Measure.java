package gr.doit4me.randomwalk.data;

import java.util.*;

import java.awt.geom.*;

/**
 * @author Dimitris Kouzis-Loukas
 * @version 1.0
 */

public class Measure {
  private Vector points = new Vector();
  private double maxx;
  private double maxy;
  private double minx;
  private double miny;
  private double r;
  private double rm;
  private String description = "";

  public Measure() {
    resetMaximums();
  }

  public Point2D[] getPoints() {
    Point2D[] retVal = new Point2D[points.size()];
    Object[] points = this.points.toArray();
    for (int i = 0; i < points.length; i++) {
      retVal[i] = (Point2D) points[i];
    }
    return retVal;
  }

  public Point2D getPoint(int index) {
    return (Point2D) points.get(index);
  }

  public Point2D getLastPoint() {
    try {
      return (Point2D) points.lastElement();
    }
    catch (java.util.NoSuchElementException ex) {
      return null;
    }
  }

  public void appendPoints(Point2D[] points) {
    if (points != null) {
      for (int i = 0; i < points.length; i++) {
        this.appendPoint(points[i]);
      }
    }
  }

  public void appendPoint(Point2D point) {
    if (point != null) {
      points.add(point);
      double x = point.getX();
      double y = point.getY();
      if (x < this.minx) {
        this.minx = point.getX();
      }
      if (x > this.maxx) {
        this.maxx = point.getX();
      }
      if (y < this.miny) {
        this.miny = point.getY();
      }
      if (y > this.maxy) {
        this.maxy = point.getY();
      }
      r = x * x + y * y;
      if (r > rm) {
        rm = r;
      }
    }
  }

  public double getMaxX() {
    return maxx;
  }

  public double getMaxY() {
    return maxy;
  }

  public double getMinX() {
    return minx;
  }

  public double getMinY() {
    return miny;
  }

  public int getPointCount() {
    return points.size();
  }

  private void resetMaximums() {
    maxx = Double.NEGATIVE_INFINITY;
    maxy = Double.NEGATIVE_INFINITY;
    minx = Double.POSITIVE_INFINITY;
    miny = Double.POSITIVE_INFINITY;
    r = 0;
    rm = 0;
  }

  public Measure subPath(int step) {
    if (step > points.size()) {
      return this;
    }
    Measure retval = new Measure ();
    Point2D[] points = getPoints();
    for (int i = 0; i < step - 1; i++) {
      retval.appendPoint(points[i]);
    }
    return retval;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String toString() {
    return description;
  }

  public double getR() {
    return Math.sqrt(r);
  }

  public double getRm() {
    return Math.sqrt(rm);
  }

  public void setR(double r) {
    this.r = r * r;
  }

  public void setRm(double rm) {
    this.rm = rm * rm;
  }
}