package gr.doit4me.randomwalk.algorithm;

public abstract class SamplePolicy {
  private static SamplePolicy source1 = new LinearSamplePolicy ();
  private static SamplePolicy source2 = new ExpSamplePolicy ();

  public abstract int getCursor(int i);
  public abstract String getDescription();
  public abstract void setMin(int min);
  public abstract void setMax(int max);
  public abstract void setSteps(int steps);
  public abstract int getMin();
  public abstract int getMax();
  public abstract int getSteps();
  public abstract SamplePolicy getCopy();

  public static SamplePolicy getInstance(String description) {
    if (description.equals(source1.getDescription())) {
      return source1.getCopy();
    }
    if (description.equals(source2.getDescription())) {
      return source2.getCopy();
    }
    return null;
  }

  public static String[] getOptions() {
    return new String[] { source1.getDescription(), source2.getDescription()};
  }
}