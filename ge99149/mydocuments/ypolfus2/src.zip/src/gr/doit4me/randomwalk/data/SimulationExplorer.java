package gr.doit4me.randomwalk.data;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.*;

public class SimulationExplorer
    extends JPanel {
  Simulation metaPathPack;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JSplitPane jSplitPane1 = new JSplitPane();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTree simulationTree = new JTree();
  BorderLayout borderLayout3 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  MeasureAnimator animator = new MeasureAnimator ();
  CardLayout cardLayout1 = new CardLayout();
  SimulationView metaPanel = new SimulationView ();
  JLabel statusBar = new JLabel();
  LogoPanel logoPanel = new LogoPanel();
  RunView pathPackInfoPanel = new RunView ();

  public SimulationExplorer() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(borderLayout3);
    jPanel3.setLayout(borderLayout4);
    simulationTree.addTreeSelectionListener(new
        MetaPathPackView_jTree1_treeSelectionAdapter(this));
    simulationTree.setModel(null);
    jSplitPane1.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    this.setPreferredSize(new Dimension(600, 400));
    jPanel5.setLayout(cardLayout1);
    statusBar.setText(" Random Walker 2003 by Dimitris Kouzis - Loukas");
    jPanel3.setBorder(BorderFactory.createLoweredBevelBorder());
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(statusBar, BorderLayout.WEST);
    jPanel1.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jSplitPane1, BorderLayout.CENTER);
    jSplitPane1.add(jScrollPane1, JSplitPane.LEFT);
    jSplitPane1.add(jPanel5, JSplitPane.RIGHT);
    jPanel5.add(animator, "animator");
    jPanel5.add(metaPanel, "metaPathPanel");
    jPanel5.add(logoPanel, "logopanel");
    jPanel5.add(pathPackInfoPanel, "pathPackInfoPanel");
    jScrollPane1.getViewport().add(simulationTree, null);
    jSplitPane1.setDividerLocation(150);
    simulationTree.getSelectionModel().setSelectionMode
        (TreeSelectionModel.SINGLE_TREE_SELECTION);
    showLogo();
  }

  public void showLogo() {
    ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "logopanel");
  }

  public Simulation getMetaPathPack() {
    return metaPathPack;
  }

  public void setMetaPathPack(Simulation metaPathPack) {
    this.metaPathPack = metaPathPack;
    simulationTree.setEnabled(metaPathPack != null);
    if (metaPathPack != null) {
      simulationTree.setModel(new SimulationTreeModel (metaPathPack));
      metaPanel.setMetaPathPack(metaPathPack);
      ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "metaPathPanel");
    }
    else {
      ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "logopanel");
    }
  }

  void jTree1_valueChanged(TreeSelectionEvent e) {
    Object obj = simulationTree.getLastSelectedPathComponent();
    if (obj instanceof Measure) {
      animator.setPath( (Measure) obj);
      ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "animator");
    }
    if (obj instanceof Run) {
      pathPackInfoPanel.setPathPack( (Run) obj);
      ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "pathPackInfoPanel");
    }
    if (obj instanceof Simulation) {
      metaPanel.setMetaPathPack( (Simulation) obj);
      ( (CardLayout) jPanel5.getLayout()).show(jPanel5, "metaPathPanel");
    }
  }
}

class MetaPathPackView_jTree1_treeSelectionAdapter
    implements javax.swing.event.TreeSelectionListener {
  SimulationExplorer adaptee;

  MetaPathPackView_jTree1_treeSelectionAdapter(SimulationExplorer adaptee) {
    this.adaptee = adaptee;
  }

  public void valueChanged(TreeSelectionEvent e) {
    adaptee.jTree1_valueChanged(e);
  }
}