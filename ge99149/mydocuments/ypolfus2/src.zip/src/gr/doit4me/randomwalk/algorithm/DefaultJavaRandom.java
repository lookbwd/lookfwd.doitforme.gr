package gr.doit4me.randomwalk.algorithm;

/**
 * @author Dimitris Kouzis-Loukas
 * @version 1.0
 */

public class DefaultJavaRandom
    implements RandomNumberGenerator {
  public DefaultJavaRandom() {
  }

  public String getDescription() {
    return "Java standart random number generator (Math.random)";
  }

  public double getNumber() {
    return Math.random();
  }

}