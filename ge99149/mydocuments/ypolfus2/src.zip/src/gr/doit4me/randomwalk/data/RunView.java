package gr.doit4me.randomwalk.data;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

import org.jfree.chart.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.*;
import org.jfree.data.*;

public class RunView
    extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  Run pathPack;
  Run previousPathPack;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel generalInfo = new JPanel();
  JPanel Histogram = new JPanel();
  TitledBorder titledBorder1;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel1 = new JLabel();
  JTextField timeField = new JTextField();
  GridLayout gridLayout2 = new GridLayout();
  GridLayout gridLayout3 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JTextField rmmeso = new JTextField();
  JPanel jPanel3 = new JPanel();
  GridLayout gridLayout4 = new GridLayout();
  JLabel jLabel3 = new JLabel();
  JTextField deltaRmeso = new JTextField();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel4 = new JLabel();
  GridLayout gridLayout5 = new GridLayout();
  JTextField deltaRmmeso = new JTextField();
  JPanel jPanel5 = new JPanel();
  JLabel jLabel5 = new JLabel();
  GridLayout gridLayout6 = new GridLayout();
  JTextField rmeso = new JTextField();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel6 = new JLabel();
  GridLayout gridLayout7 = new GridLayout();
  JPanel jPanel7 = new JPanel();
  JTextField description = new JTextField();
  JLabel jLabel7 = new JLabel();
  JTextField numberOfSteps = new JTextField();
  GridLayout gridLayout8 = new GridLayout();
  JPanel jPanel8 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  ChartPanel histo_panel = new ChartPanel(new JFreeChart(new XYPlot()), true, true, true, true, true);

  public static int CATEGORY_NO = 25;

  public RunView() {
    try {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(148, 145, 140)), "Run info view");
    this.setLayout(borderLayout1);
    jTabbedPane1.setTabPlacement(JTabbedPane.BOTTOM);
    jTabbedPane1.setBorder(titledBorder1);
    jTabbedPane1.addChangeListener(new PathPackView_jTabbedPane1_changeAdapter(this));
    generalInfo.setLayout(borderLayout2);
    jPanel2.setLayout(gridLayout1);
    jLabel1.setText("Calculation time (ms):");
    timeField.setEditable(false);
    gridLayout1.setColumns(2);
    jPanel1.setMaximumSize(new Dimension(32767, 32767));
    jPanel1.setLayout(gridLayout2);
    gridLayout2.setRows(7);
    gridLayout3.setColumns(2);
    jLabel2.setText("<Rm^2>");
    rmmeso.setEditable(false);
    jPanel3.setLayout(gridLayout3);
    gridLayout4.setColumns(2);
    jLabel3.setText("delta R^2:");
    deltaRmeso.setEditable(false);
    jPanel4.setLayout(gridLayout4);
    jLabel4.setText("delta Rm^2:");
    gridLayout5.setColumns(2);
    deltaRmmeso.setEditable(false);
    jPanel5.setLayout(gridLayout5);
    jLabel5.setText("<R^2>:");
    gridLayout6.setColumns(2);
    rmeso.setEditable(false);
    jPanel6.setLayout(gridLayout6);
    jLabel6.setText("Description:");
    gridLayout7.setColumns(2);
    jPanel7.setLayout(gridLayout7);
    description.setEditable(false);
    jLabel7.setText("Number of steps:");
    numberOfSteps.setEditable(false);
    gridLayout8.setColumns(2);
    jPanel8.setLayout(gridLayout8);
    Histogram.setLayout(borderLayout3);
    this.add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(generalInfo, "General Information");
    generalInfo.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jPanel7, null);
    jPanel1.add(jPanel8, null);
    jPanel1.add(jPanel2, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(timeField, null);
    jPanel8.add(jLabel7, null);
    jPanel7.add(jLabel6, null);
    jPanel7.add(description, null);
    jPanel1.add(jPanel6, null);
    jPanel6.add(jLabel5, null);
    jPanel6.add(rmeso, null);
    jPanel1.add(jPanel4, null);
    jPanel4.add(jLabel3, null);
    jPanel4.add(deltaRmeso, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jLabel2, null);
    jPanel3.add(rmmeso, null);
    jTabbedPane1.add(Histogram, "Histogram");
    jPanel5.add(jLabel4, null);
    jPanel5.add(deltaRmmeso, null);
    jPanel1.add(jPanel5, null);
    jPanel8.add(numberOfSteps, null);
    Histogram.add(histo_panel, BorderLayout.CENTER);
  }

  public Run getPathPack() {
    return pathPack;
  }

  public void setPathPack(Run pathPack) {
    this.pathPack = pathPack;
    //jTabbedPane1.setSelectedIndex(0);
    timeField.setText(String.valueOf(trimToTwoDecimal (pathPack.getTime())));
    rmeso.setText(String.valueOf(trimToTwoDecimal (pathPack.getRavv())));
    deltaRmeso.setText(String.valueOf(trimToTwoDecimal (pathPack.getDeltaRavv())));
    rmmeso.setText(String.valueOf(trimToTwoDecimal (pathPack.getRmAvv())));
    deltaRmmeso.setText(String.valueOf(trimToTwoDecimal (pathPack.getDeltaRmavv())));
    description.setText(pathPack.getDescription());
    numberOfSteps.setText(String.valueOf(pathPack.getNumberOfSteps()));
    if (jTabbedPane1.getSelectedIndex() != 0) {
      jTabbedPane1_stateChanged(new ChangeEvent(this));
    }
  }

  public void jTabbedPane1_stateChanged(ChangeEvent e) {
    if (jTabbedPane1.getSelectedComponent() == Histogram &&
        pathPack != previousPathPack) {
      previousPathPack = pathPack;

      Measure[] pathArr = pathPack.getPack();
      int length = pathArr.length;
      double min = pathArr[0].getR();
      double max = pathArr[0].getR();

      for (int i = 1; i < length; i++) {
        if (pathArr[i].getR() > max) {
          max = pathArr[i].getR();
        }
        if (pathArr[i].getR() < min) {
          min = pathArr[i].getR();
        }
      }
      double range = max - min;
      double step = range / CATEGORY_NO;
      double[] categoryLower = new double[CATEGORY_NO];
      int[] counts = new int[CATEGORY_NO];

      categoryLower[0] = min;
      counts[0] = 0;
      for (int i = 0; i < CATEGORY_NO - 1; i++) {
        categoryLower[i + 1] = categoryLower[i] + step;
        counts[i] = 0;
      }

      for (int i = 0; i < length; i++) {
        for (int k = 0; k < CATEGORY_NO; k++) {
          if (pathArr[i].getR() >= categoryLower[k] &&
              pathArr[i].getR() < categoryLower[k] + step) {
            counts[k]++;
            break;
          }
        }
        if (pathArr[i].getR() == categoryLower[CATEGORY_NO - 1] + step) {
          counts[CATEGORY_NO - 1]++;
        }
      }

      // Create graph
      CategoryAxis xScale = new CategoryAxis("R distribution");
      NumberAxis yScale = new NumberAxis("Counts");
      xScale.setVerticalCategoryLabels(true);

      DefaultCategoryDataset dataset = new DefaultCategoryDataset();

      for (int i = 0; i < CATEGORY_NO; i++) {
        dataset.addValue(counts[i], new Integer(0),
                         new MyLabel(i,
                                     trimToOneDecimal(categoryLower[i]) + " - " +
                                     trimToOneDecimal( (categoryLower[i] + step))));
      }
      CategoryPlot jplot = new CategoryPlot(dataset, xScale, yScale,
                                            new BarRenderer());
      histo_panel.setChart(new JFreeChart(jplot));
    }
  }

  private double trimToOneDecimal(double in) {
    return Math.floor(in * 10) / 10;
  }

  private double trimToTwoDecimal(double in) {
    return Math.floor(in * 100) / 100;
  }
}

class MyLabel
    implements Comparable {
  int position;
  String text;
  public MyLabel(int position, String text) {
    this.position = position;
    this.text = text;
  }

  public int compareTo(Object o) {
    if (o instanceof MyLabel) {
      return ( (MyLabel) o).position - position;
    }
    return -1;
  }

  public String toString() {
    return text;
  }

}

class PathPackView_jTabbedPane1_changeAdapter
    implements javax.swing.event.ChangeListener {
  RunView adaptee;

  PathPackView_jTabbedPane1_changeAdapter(RunView adaptee) {
    this.adaptee = adaptee;
  }

  public void stateChanged(ChangeEvent e) {
    adaptee.jTabbedPane1_stateChanged(e);
  }
}