package gr.doit4me.randomwalk.algorithm;

/**
 * @author Dimitris Kouzis-Loukas
 * @version 1.0
 */

public interface RandomNumberGenerator {
  public String getDescription();

  public double getNumber();
}