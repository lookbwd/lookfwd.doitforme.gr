package gr.doit4me.randomwalk.data;

import java.io.Serializable;
import gr.doit4me.randomwalk.algorithm.Settings;

public class Simulation {
  private Run[] metaPathPack = new Run[0];
  private Settings settings = new Settings();

  private String description = "";

  public Simulation() {
  }

  public Run[] getMetaPathPack() {
    return metaPathPack;
  }

  public void setMetaPathPack(Run[] metaPathPack) {
    this.metaPathPack = metaPathPack;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getDescription() {
    return description;
  }

  public String toString() {
    return description;
  }

  public Settings getSettings() {
    return settings;
  }

  public void setSettings(Settings settings) {
    this.settings = settings;
  }
}