package gr.doit4me.randomwalk.algorithm;

public class Settings {
  private int repeats = 10;
  private boolean holdIdivindual = true;
  private boolean do3D = false;
  private SamplePolicy policy = new LinearSamplePolicy ();

  public Settings() {
  }

  public Settings(Settings settings) {
    policy = settings.policy.getCopy();
    repeats = settings.repeats;
    holdIdivindual = settings.holdIdivindual;
    do3D = settings.do3D;
  }

  public int getRepeats() {
    return repeats;
  }

  public void setRepeats(int repeats) {
    this.repeats = repeats;
  }

  public void setHoldIdivindual(boolean holdIdivindual) {
    this.holdIdivindual = holdIdivindual;
  }

  public boolean isHoldIdivindual() {
    return holdIdivindual;
  }

  public void setDo3D(boolean do3D) {
    this.do3D = do3D;
  }

  public boolean isDo3D() {
    return do3D;
  }
  public SamplePolicy getPolicy() {
    return policy;
  }
  public void setPolicy(SamplePolicy policy) {
    this.policy = policy;
  }
}