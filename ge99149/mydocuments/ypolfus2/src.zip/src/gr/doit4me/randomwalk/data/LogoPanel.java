package gr.doit4me.randomwalk.data;

import java.awt.*;
import javax.swing.*;

public class LogoPanel
    extends JPanel {
  ImageIcon image1;
  JLabel imageLabel = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();

  public LogoPanel() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    image1 = new ImageIcon(gr.doit4me.randomwalk.data.LogoPanel.class.
                           getResource("ourLogoOut.png"));
    imageLabel.setText("");
    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    imageLabel.setIcon(image1);
    this.setBackground(Color.white);
    this.setLayout(borderLayout1);
    jPanel1.setBackground(Color.white);
    jPanel1.setDebugGraphicsOptions(0);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(gridLayout1);
    gridLayout1.setColumns(0);
    gridLayout1.setRows(2);
    jLabel1.setForeground(new Color(58, 110, 165));
    jLabel2.setForeground(new Color(58, 110, 165));
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setText(
        " Random Walker 2003 by Dimitris Kouzis - Loukas (lookfwd@mail.ntua.gr)");
    jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel2.setText("Stop walking... Start flying!");
    jPanel2.setBackground(Color.white);
    this.add(imageLabel, BorderLayout.CENTER);
    this.add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(jPanel2, BorderLayout.SOUTH);
    jPanel2.add(jLabel1, null);
    jPanel2.add(jLabel2, null);
  }

}