package gr.doit4me.randomwalk.data;

public class Run {
  private Measure[] pack = new Measure[0];
  private String description = "";
  private double time = -1;

  private double rmAvv = 0;
  private double ravv = 0;
  private double deltaRavv = 0;
  private double deltaRmavv = 0;

  private int numberOfSteps = 0;
  public Run() {
  }

  public Measure[] getPack() {
    return pack;
  }

  public void setPack(Measure[] pack) {
    Measure s;
    this.pack = pack;
    rmAvv = 0;
    ravv = 0;
    int loops = pack.length;
    for (int i = 0; i < loops; i++) {
      s = pack[i];
      if (s != null) {
        ravv += s.getR() * s.getR();
        rmAvv += s.getRm() * s.getRm();
      }
    }
    ravv /= (double) loops;
    rmAvv /= (double) loops;

    deltaRavv = 0;
    deltaRmavv = 0;
    for (int i = 0; i < loops; i++) {
      s = pack[i];
      if (s != null) {
        double f = ( (s.getR() * s.getR()) - ravv);
        deltaRavv += f * f;
        f = ( (s.getRm() * s.getRm()) - rmAvv);
        deltaRmavv += f * f;
      }
    }
    deltaRavv /= (double) (loops * (loops - 1));
    deltaRmavv /= (double) (loops * (loops - 1));
    deltaRavv = Math.sqrt(deltaRavv);
    deltaRmavv = Math.sqrt(deltaRmavv);
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String toString() {
    return description;
  }

  public double getTime() {
    return time;
  }

  public void setTime(double time) {
    this.time = time;
  }

  public double getRavv() {
    return ravv;
  }

  public double getRmAvv() {
    return rmAvv;
  }

  public double getDeltaRavv() {
    return deltaRavv;
  }

  public double getDeltaRmavv() {
    return deltaRmavv;
  }

  public int getNumberOfSteps() {
    return numberOfSteps;
  }

  public void setNumberOfSteps(int numberOfSteps) {
    this.numberOfSteps = numberOfSteps;
  }
}