package gr.doit4me.randomwalk.data;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class MeasureView
    extends JComponent {
  Measure path;

  public MeasureView() {
    setBackground(Color.WHITE);
  }

  public Measure getPath() {
    return path;
  }

  public void setPath(Measure path) {
    this.path = path;
    repaint();
  }

  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    if (path != null && g != null) {
      double modelSpace = Math.max(Math.abs(path.getMaxX()),
                                   Math.max(Math.abs(path.getMaxY()),
                                            Math.max(Math.abs(path.getMinY()),
          Math.abs(path.getMinX()))));

      if (modelSpace == Double.POSITIVE_INFINITY) {
        return;
      }
      Insets insets = getInsets();
      double scale = (Math.min(getWidth() - insets.right - insets.left,
                               getHeight() - insets.top - insets.bottom) / 2) /
          modelSpace;
      Point2D previousPoint = new Point(0, 0);
      Point2D[] points = path.getPoints();

      double offsetX = getWidth() / 2;
      double offsetY = getHeight() / 2;

      for (int i = 0; i < points.length; i++) {
        g.drawLine( (int) (previousPoint.getX() * scale + offsetX),
                   (int) ( -previousPoint.getY() * scale + offsetY),
                   (int) (points[i].getX() * scale + offsetX),
                   (int) ( -points[i].getY() * scale + offsetY));
        previousPoint = points[i];
      }
    }
  }

}