package gr.doit4me.randomwalk.data;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

import org.jfree.chart.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.*;
import org.jfree.data.*;
import gr.doit4me.randomwalk.algorithm.*;
import java.awt.event.*;

public class SimulationView
    extends JPanel
    implements java.awt.event.ActionListener {
  private Simulation metaPathPack;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  TitledBorder titledBorder1;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel7 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel1 = new JLabel();
  JTextField totalTime = new JTextField();
  GridLayout gridLayout2 = new GridLayout();
  JTextField maxStepNo = new JTextField();
  JLabel jLabel3 = new JLabel();
  GridLayout gridLayout4 = new GridLayout();
  JPanel jPanel9 = new JPanel();
  JTextField minStepNo = new JTextField();
  JLabel jLabel5 = new JLabel();
  GridLayout gridLayout6 = new GridLayout();
  JPanel jPanel11 = new JPanel();
  JTextField stepsNo = new JTextField();
  JLabel jLabel6 = new JLabel();
  GridLayout gridLayout7 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  JTextField walksNumber = new JTextField();
  JLabel jLabel7 = new JLabel();
  GridLayout gridLayout8 = new GridLayout();
  JPanel jPanel13 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  BorderLayout borderLayout7 = new BorderLayout();
  JPanel rgraphPane = new JPanel();
  JPanel jPanel4 = new JPanel();
  JCheckBox m_logx = new JCheckBox();
  JCheckBox m_logy = new JCheckBox();
  XYSeriesCollection m_dataset;
  XYSeriesCollection rm_dataset;
  XYSeriesCollection t_dataset;
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel rmgraphPane = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  JPanel jPanel8 = new JPanel();
  JCheckBox rm_logx = new JCheckBox();
  BorderLayout borderLayout9 = new BorderLayout();
  JPanel jPanel10 = new JPanel();
  JPanel rgraphPane1 = new JPanel();
  JCheckBox rm_logy = new JCheckBox();
  BorderLayout borderLayout10 = new BorderLayout();
  JPanel jPanel14 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JPanel timegraphPane = new JPanel();
  BorderLayout borderLayout6 = new BorderLayout();
  BorderLayout borderLayout11 = new BorderLayout();
  JPanel jPanel16 = new JPanel();
  JCheckBox t_logx = new JCheckBox();
  JCheckBox t_logy = new JCheckBox();
  JPanel jPanel17 = new JPanel();
  GridLayout gridLayout3 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JCheckBox simul3d = new JCheckBox();
  JPanel jPanel18 = new JPanel();
  JLabel jLabel4 = new JLabel();
  JTextField numberPolicy = new JTextField();
  GridLayout gridLayout5 = new GridLayout();

  public SimulationView() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(148, 145, 140)), "Simulation view");
    this.setLayout(borderLayout1);
    jPanel1.setBorder(titledBorder1);
    jPanel1.setLayout(borderLayout2);
    jTabbedPane1.setTabPlacement(JTabbedPane.BOTTOM);
    jPanel2.setLayout(borderLayout3);
    jPanel6.setLayout(gridLayout1);
    gridLayout1.setRows(7);
    jLabel1.setText("Total calculation time (ms):");
    jPanel7.setLayout(gridLayout2);
    gridLayout2.setColumns(2);
    jLabel3.setText("Maximum step number:");
    gridLayout4.setColumns(2);
    jPanel9.setLayout(gridLayout4);
    jLabel5.setText("Minimum step number:");
    gridLayout6.setColumns(2);
    jPanel11.setLayout(gridLayout6);
    jLabel6.setText("Number of steps:");
    gridLayout7.setColumns(2);
    jPanel12.setLayout(gridLayout7);
    jLabel7.setText("Number of repeats:");
    gridLayout8.setColumns(2);
    jPanel13.setLayout(gridLayout8);
    jPanel3.setLayout(borderLayout4);
    rgraphPane.setLayout(borderLayout7);
    m_logx.setText("log x");
    m_logx.addActionListener(this);
    m_logy.setText("log y");
    m_logy.addActionListener(this);
    rmgraphPane.setLayout(borderLayout5);
    jPanel5.setLayout(borderLayout8);
    rm_logx.addActionListener(this);
    rm_logx.setText("log x");
    rgraphPane1.setLayout(borderLayout10);
    rm_logy.setText("log y");
    rm_logy.addActionListener(this);
    jPanel14.setLayout(borderLayout9);
    timegraphPane.setLayout(borderLayout6);
    jPanel15.setLayout(borderLayout11);
    t_logx.setText("log x");
    t_logx.addActionListener(this);
    t_logy.addActionListener(this);
    t_logy.setText("log y");
    walksNumber.setEditable(false);
    totalTime.setEditable(false);
    stepsNo.setEditable(false);
    minStepNo.setEditable(false);
    maxStepNo.setEditable(false);
    jPanel17.setLayout(gridLayout3);
    gridLayout3.setColumns(2);
    jLabel2.setText("3D simulation:");
    simul3d.setEnabled(false);
    simul3d.setText("3D simulation");
    jLabel4.setText("Sample distribution:");
    numberPolicy.setEditable(false);
    numberPolicy.setText("");
    jPanel18.setLayout(gridLayout5);
    gridLayout5.setColumns(2);
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(jPanel2, "General Info");
    jPanel2.add(jPanel6, BorderLayout.NORTH);
    jPanel6.add(jPanel7, null);
    jPanel7.add(jLabel1, null);
    jPanel7.add(totalTime, null);
    jPanel6.add(jPanel13, null);
    jPanel13.add(jLabel7, null);
    jPanel13.add(walksNumber, null);
    jPanel6.add(jPanel18, null);
    jPanel6.add(jPanel12, null);
    jPanel12.add(jLabel6, null);
    jPanel12.add(stepsNo, null);
    jPanel6.add(jPanel11, null);
    jPanel11.add(jLabel5, null);
    jPanel11.add(minStepNo, null);
    jPanel6.add(jPanel9, null);
    jPanel9.add(jLabel3, null);
    jPanel9.add(maxStepNo, null);
    jPanel6.add(jPanel17, null);
    jPanel17.add(jLabel2, null);
    jPanel17.add(simul3d, null);
    jPanel18.add(jLabel4, null);
    jPanel18.add(numberPolicy, null);
    jTabbedPane1.add(jPanel3, "Graph R^2");
    jPanel3.add(rgraphPane, BorderLayout.CENTER);
    jPanel3.add(jPanel4, BorderLayout.SOUTH);
    jPanel4.add(m_logx, null);
    jPanel4.add(m_logy, null);
    jTabbedPane1.add(jPanel5, "Graph Rm^2");
    jPanel5.add(rmgraphPane, BorderLayout.CENTER);
    jPanel5.add(jPanel8, BorderLayout.SOUTH);
    jPanel14.add(rgraphPane1, BorderLayout.CENTER);
    jPanel14.add(jPanel10, BorderLayout.SOUTH);
    jPanel10.add(rm_logx, null);
    jPanel10.add(rm_logy, null);
    jTabbedPane1.add(jPanel15, "Graph Tsim");
    jPanel15.add(timegraphPane, BorderLayout.CENTER);
    jPanel15.add(jPanel16, BorderLayout.SOUTH);
    jPanel16.add(t_logx, null);
    jPanel16.add(t_logy, null);
    jPanel8.add(jPanel14, null);
  }

  public void setMetaPathPack(Simulation obj) {
    metaPathPack = obj;
    if (metaPathPack == null) {
      totalTime.setText(" ");
    }
    else {
      double time = 0;
      Run[] pack = metaPathPack.getMetaPathPack();
      Settings settings = metaPathPack.getSettings();
      if (settings != null) {
        for (int i = 0; i < pack.length; i++) {
          time += pack[i].getTime();
        }
        int repeats = settings.getRepeats();
        totalTime.setText(String.valueOf(Math.floor(time * repeats)));
        walksNumber.setText(String.valueOf(repeats));
        SamplePolicy policy = settings.getPolicy();
        if (policy!=null) {
          stepsNo.setText(String.valueOf(policy.getSteps()));
          minStepNo.setText(String.valueOf(policy.getMin()));
          maxStepNo.setText(String.valueOf(policy.getMax()));
          numberPolicy.setText(policy.getDescription());
        }
        simul3d.setSelected(settings.isDo3D());
        setCompEnabled(true);
        createRGraph();
        createRMGraph();
        createTGraph();
      }
      else {
        totalTime.setText(" ");
        walksNumber.setText(" ");
        stepsNo.setText(" ");
        minStepNo.setText(" ");
        maxStepNo.setText(" ");
        simul3d.setSelected(false);
        setCompEnabled(false);
      }
    }
    jTabbedPane1.setSelectedIndex(0);
  }

  private void createRGraph() {
    rgraphPane.removeAll();
    Run[] pack = metaPathPack.getMetaPathPack();
    XYSeries xySeries = new XYSeries("R^2 paint");
    for (int i = 0; i < pack.length; i++) {
      xySeries.add(pack[i].getNumberOfSteps(), pack[i].getRavv());
    }
    m_dataset = new XYSeriesCollection(xySeries);
    updatePanel(rgraphPane, m_logx.isSelected(), m_logy.isSelected(), "t",
                "<R^2>", m_dataset);
  }

  private void createRMGraph() {
    Run[] pack = metaPathPack.getMetaPathPack();
    XYSeries xySeries = new XYSeries("Rm^2 paint");
    for (int i = 0; i < pack.length; i++) {
      xySeries.add(pack[i].getNumberOfSteps(), pack[i].getRmAvv());
    }
    rm_dataset = new XYSeriesCollection(xySeries);
    updatePanel(rmgraphPane, rm_logx.isSelected(), rm_logy.isSelected(), "t",
                "<Rm^2>", rm_dataset);
  }

  private void createTGraph() {
    timegraphPane.removeAll();
    Run[] pack = metaPathPack.getMetaPathPack();
    XYSeries xySeries = new XYSeries("Tsim paint");
    for (int i = 0; i < pack.length; i++) {
      if (pack[i].getTime() > 0) {
        xySeries.add(pack[i].getNumberOfSteps(), pack[i].getTime());
      }
      else {
        xySeries.add(pack[i].getNumberOfSteps(), 0.01);
      }
    }
    t_dataset = new XYSeriesCollection(xySeries);
    updatePanel(timegraphPane, t_logx.isSelected(), t_logy.isSelected(), "t",
                "Tsim (ms)", t_dataset);
  }

  private void setCompEnabled(boolean state) {
    totalTime.setEnabled(state);
    walksNumber.setEnabled(state);
    stepsNo.setEnabled(state);
    minStepNo.setEnabled(state);
    maxStepNo.setEnabled(state);
    m_logy.setEnabled(state);
    m_logx.setEnabled(state);
    rm_logy.setEnabled(state);
    rm_logx.setEnabled(state);
    t_logy.setEnabled(state);
    t_logx.setEnabled(state);
  }

  private void updatePanel(JPanel panel, boolean logx, boolean logy,
                           String xlabel, String ylabel,
                           XYSeriesCollection dataset) {
    if (panel != null && dataset != null) {
      NumberAxis xScale, yScale;
      if (logx) {
        xScale = new LogarithmicAxis(xlabel);
      }
      else {
        xScale = new NumberAxis(xlabel);
      }
      if (logy) {
        yScale = new LogarithmicAxis(ylabel);
      }
      else {
        yScale = new NumberAxis(ylabel);
      }
      xScale.setAutoRangeIncludesZero(false);
      yScale.setAutoRangeIncludesZero(false);
      XYPlot jplot = new XYPlot(dataset, xScale, yScale,
                                new StandardXYItemRenderer());
      panel.removeAll();
      panel.add(new ChartPanel(new JFreeChart(jplot), true, true, true, true, true),
                BorderLayout.CENTER);
    }
  }

  public Simulation getMetaPathPack() {
    return metaPathPack;
  }

  public void actionPerformed(ActionEvent e) {
    Object source = e.getSource();
    if (source == m_logx || source == m_logy) {
      updatePanel(rgraphPane, m_logx.isSelected(), m_logy.isSelected(), "t",
                  "<R^2>", m_dataset);
      repaint();
    }
    if (source == rm_logx || source == rm_logy) {
      updatePanel(rmgraphPane, rm_logx.isSelected(), rm_logy.isSelected(), "t",
                  "<Rm^2>", rm_dataset);
      repaint();
    }
    if (source == t_logx || source == t_logy) {
      updatePanel(timegraphPane, t_logx.isSelected(), t_logy.isSelected(), "t",
                  "Tsim (ms)", t_dataset);
      repaint();
    }
  }
}