package gr.doit4me.randomwalk.algorithm;

import gr.doit4me.randomwalk.data.Simulation;

/**
 * @author Dimitris Kouzis-Loukas
 * @version 1.0
 */

public interface RandomWalkAlgorithm {
  public RandomNumberGenerator getGenerator();

  public void setGenerator(RandomNumberGenerator generator);

  public Simulation doWalk(Simulation pack);
}