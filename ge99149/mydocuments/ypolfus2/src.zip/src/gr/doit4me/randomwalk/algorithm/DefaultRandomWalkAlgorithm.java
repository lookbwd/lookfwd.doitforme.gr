package gr.doit4me.randomwalk.algorithm;

import java.awt.geom.Point2D;
import java.awt.Point;
import java.util.Date;
import gr.doit4me.randomwalk.data.*;
import javax.swing.ProgressMonitor;

/**
 * @author Dimitris Kouzis-Loukas
 * @version 1.0
 */

public class DefaultRandomWalkAlgorithm
    implements RandomWalkAlgorithm {
  private RandomNumberGenerator generator = new DefaultJavaRandom ();

  public DefaultRandomWalkAlgorithm() {
  }

  public RandomNumberGenerator getGenerator() {
    return generator;
  }

  public void setGenerator(RandomNumberGenerator generator) {
    this.generator = generator;
  }

  /**
   * Method that performs simulation and stores results to a MetaPathPack.
   * @param source_pack The source pack that contains simulation settings.
   * @return The result pack containing settings and simulation data.
   */
  public Simulation doWalk(Simulation source_pack) {
    if (source_pack == null) {
      return null;
    }
    // Retrieve settings
    Settings settings = source_pack.getSettings();
    if (settings == null) {
      return source_pack;
    }
    SamplePolicy policy = settings.getPolicy();
    if (policy == null) {
      return source_pack;
    }
    // Analyze settings
    int metaPackItems = policy.getSteps();
    int repeats = settings.getRepeats();
    boolean hold = settings.isHoldIdivindual();
    boolean run3d = settings.isDo3D();

    // Create new MetaPathPack to hold data.
    source_pack = new Simulation ();
    source_pack.setSettings(new Settings(settings));

    // Create process progress monitor.
    ProgressMonitor monitor = new ProgressMonitor(null, null,
                                                  "Performing simulation...", 0,
                                                  metaPackItems);
    monitor.setMillisToDecideToPopup(0);
    monitor.setMillisToPopup(0);

    // All the memory is allocated at the begining to avoi garbage collector
    // run later. e.g. while measuring time.
    System.gc();
    Run[] pack = new Run[metaPackItems];
    for (int i = 0; i < metaPackItems; i++) {
      pack[i] = new Run ();
      Measure[] walkPath = new Measure[repeats];
      pack[i].setPack(walkPath);
      int points = policy.getCursor(i);
      pack[i].setDescription(points + " steps run");
      pack[i].setNumberOfSteps(points);
      for (int k = 0; k < repeats; k++) {
        walkPath[k] = new Measure ();
        walkPath[k].setDescription("Run #" + (k + 1));
      }
    }
    System.gc();

    // For every point value defined by settings...
    for (int i = 0; i < metaPackItems; i++) {
      monitor.setProgress(i);
      int points = policy.getCursor(i);
      Measure[] paths = pack[i].getPack();
      long time_start, time_end;

      if (hold) {
        // If hold run slow procedure to create package of runs.
        time_start = System.currentTimeMillis();
        for (int k = 0; k < repeats; k++) {
          completeRun(points, paths[k]);
        }
        time_end = System.currentTimeMillis();
      }
      else {
        if (run3d) {
          // if 3D run selected run fast 3D procedure to create package of runs.
          time_start = System.currentTimeMillis();
          for (int k = 0; k < repeats; k++) {
            fast3DRun(points, paths[k]);
          }
          time_end = System.currentTimeMillis();
        }
        else {
          // Else run fast procedure to create package of runs.
          time_start = System.currentTimeMillis();
          for (int k = 0; k < repeats; k++) {
            fastRun(points, paths[k]);
          }
          time_end = System.currentTimeMillis();
        }
      }
      // Calculate sumulation time.
      pack[i].setTime( ( (double) (time_end - time_start)) / repeats);
      // Add run to simulation.
      pack[i].setPack(paths);
    }
    // Close monitor.
    monitor.close();
    // Update simulation data by including new data.
    source_pack.setMetaPathPack(pack);
    source_pack.setDescription("Simulation " + (new Date()).toString());
    return source_pack;
  }

  /**
   * Slow run process.
   * @param points The number of points (steps) for this run.
   * @param path The path that the points have to be addeed to.
   */
  protected void completeRun(int points, Measure path) {
    Point2D previousPoint;
    path.appendPoint(previousPoint = new Point(0, 0));
    int random, x, y;
    for (int i = 0; i < points; i++) {

      random = (int) (generator.getNumber() * 4);
      x = (int) previousPoint.getX();
      y = (int) previousPoint.getY();

      if (random == 0) {
        path.appendPoint(previousPoint = new Point(x + 1, y));
      }
      else if (random == 1) {
        path.appendPoint(previousPoint = new Point(x, y + 1));
      }
      else if (random == 2) {
        path.appendPoint(previousPoint = new Point(x - 1, y));
      }
      else {
        path.appendPoint(previousPoint = new Point(x, y - 1));
      }
    }
  }

  /**
   * Fast run process.
   * @param points The number of points (steps) for this run.
       * @param path The path that information about run is going to be stored into.
   */
  protected void fastRun(int points, Measure path) {
    int x = 0;
    int y = 0;
    double rm = 0;
    double r = 0;

    for (int i = 0; i < points; i++) {
      int random = (int) (generator.getNumber() * 4);
      if (random == 0) {
        x++;
      }
      else if (random == 1) {
        y++;
      }
      else if (random == 2) {
        x--;
      }
      else {
        y--;
      }
      r = x * x + y * y;
      if (r > rm) {
        rm = r;
      }
    }
    path.setR(Math.sqrt(r));
    path.setRm(Math.sqrt(rm));
  }

  /**
   * Fast 3D run process.
   * @param points The number of points (steps) for this run.
       * @param path The path that information about run is going to be stored into.
   */
  protected void fast3DRun(int points, Measure path) {
    int x = 0;
    int y = 0;
    int z = 0;
    double rm = 0;
    double r = 0;

    for (int i = 0; i < points; i++) {
      int random = (int) (generator.getNumber() * 6);
      if (random == 0) {
        x++;
      }
      else if (random == 1) {
        y++;
      }
      else if (random == 2) {
        z++;
      }
      else if (random == 3) {
        x--;
      }
      else if (random == 4) {
        y--;
      }
      else {
        z--;
      }
      r = x * x + y * y + z * z;
      if (r > rm) {
        rm = r;
      }
    }
    path.setR(Math.sqrt(r));
    path.setRm(Math.sqrt(rm));
  }
}