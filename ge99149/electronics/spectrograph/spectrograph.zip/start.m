% Init
if (exist('running')==0)
    initspectr;
end

global s;

% Running boolean variable.
running=1;

fclose(s);
fopen(s);

prev=0;
current=255;

while ((prev~=255) & (current~=0))
    prev = current;
    current=fread(s,1,'uint8');
end
set(statustext,'string','Synchronized');
fread(s,1,'uint8');

while (running)
for n=1:zipTimeSize
    average=zeros(zipSensorSize,1);
    for i=1:averageSamples
        idn = fread(s,38,'uint8');
        average=average+idn;
        fread(s,2,'uint8');
        set(h,'YData',idn);
        drawnow
    end

    average=average./averageSamples;

    set(meansqrt,'string',['Maching offset: ' int2str(sqrt(sum((average-desired).^2)))]);

    zip=zip*roll;
    zip(:,1)=average;
    set(zipHandle,'ZData',zip);
    set(zipHandle,'CData',zip);
end
end

set(statustext,'string','Stoped');