function changecom(newcom)
global s;
fig=gcbf;
statustext=findall(fig,'tag','text3');

set(findall(fig,'tag','C1'),'checked','off');
set(findall(fig,'tag','C2'),'checked','off');
set(findall(fig,'tag','C3'),'checked','off');
set(findall(fig,'tag','C4'),'checked','off');
set(gcbo,'checked','on');

fclose(s);
s = serial(newcom,'baudrate',38400);
fopen(s);


set(statustext,'string',['Setting COM : ',newcom]);