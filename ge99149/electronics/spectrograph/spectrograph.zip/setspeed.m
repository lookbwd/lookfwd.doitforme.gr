function setspeed(newspeed)
global s;

fig=gcbf;
handle=guihandles(fig);

set(handle.SHigh,'checked','off');
set(handle.SMedium,'checked','off');
set(handle.SLow,'checked','off');
set(gcbo,'checked','on');

newspeed;

fwrite(s,newspeed);

set(handle.text3,'string',['Speed set : ',int2str(newspeed)]);