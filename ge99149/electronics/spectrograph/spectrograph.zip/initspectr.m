fig=gcbf;
handles = guihandles(fig);

statustext=handles.text3;
monitor=handles.axes1;
zipdraw=handles.axes2;
meansqrt=handles.text1;

% User constants (parameters of matrices).
zipTimeSize=10;
zipSensorSize=38;
averageSamples=5;

roll=diag(ones(zipTimeSize-1,1),1);
roll=sparse(roll);


a=1:zipSensorSize;
a=a';
desired=[85;95;98;100;106;112;128;148;152;139;119;104;98;94;93;93;93;95;97;99;104;102;106;106;110;113;121;131;149;166;172;162;150;120;106;97;93;95];
nspd=0;

zip=zeros(zipSensorSize,zipTimeSize);

set(statustext,'string','Starting');
global s;
s = serial('COM1','baudrate',38400);
fopen(s);
fwrite(s,210);

set(get(monitor,'XLabel'),'String','wavelength');
set(get(monitor,'YLabel'),'String','intensity');
set(monitor,'XLim',[1 zipSensorSize]);

line(a,desired,'Color','red','parent',monitor);

h = line(a,a,'parent',monitor);

set(zipdraw,'YLim',[1 zipSensorSize]);
set(get(zipdraw,'XLabel'),'String','time');
set(get(zipdraw,'YLabel'),'String','wavelength');
set(get(zipdraw,'ZLabel'),'String','intensity');

zipHandle=surface(zip,'parent',zipdraw,'FaceColor','interp');
jet(fig);
