global s;
fig=gcbf;
statustext=findall(fig,'tag','text3');
set(statustext,'string','Exiting');
fclose(s);
close(fig);
clear all;
